from django.shortcuts import render, redirect
from django.views.generic import ListView, DetailView, DeleteView
from .models import Product

def index(request):
    return render(request, 'market/index.html')

class ProductListView(ListView):
    model = Product
    template_name = 'market/product_list.html'

class ProductDetailView(DetailView):
    model = Product
    template_name = 'market/product_detail.html'

class ProductDeleteView(DeleteView):
    model = Product
    template_name = 'market/product_delete.html'
    success_url = '/'