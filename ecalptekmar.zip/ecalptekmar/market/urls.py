
from django.urls import path
from .views import index, ProductListView, ProductDetailView, ProductDeleteView

urlpatterns = [
    path('', index, name='index'),
    path('products/', ProductListView.as_view(), name='product_list'),
    path('products/<pk>/', ProductDetailView.as_view(), name='product_detail'),
    path('products/<pk>/delete/', ProductDeleteView.as_view(), name='product_delete'),
]


